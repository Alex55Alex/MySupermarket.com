const store = {
    items: [
        {
            title: 'Semi Skimmed Low Fat Milk',
            volume: '2.272L / 4 Pints',
            recyclable: 'recyclable in your area',
            itemImage: 'milk01',
            price: '£ 2.05',
            bgColor: '#EBF5FB'
        },
        {
            title: 'Semi Skimmed Low Fat Milk',
            volume: '2.272L / 4 Pints',
            recyclable: 'recyclable in your area',
            itemImage: 'milk02',
            price: '£ 2.05',
            bgColor: '#E8F6F5'
        },
        {
            title: 'Semi Skimmed Low Fat Milk',
            volume: '2.272L / 4 Pints',
            recyclable: 'recyclable in your area',
            itemImage: 'milk03',
            price: '£ 2.05',
            bgColor: '#EBF5FB'
        },
        {
            title: 'Semi Skimmed Low Fat Milk',
            volume: '2.272L / 4 Pints',
            recyclable: 'recyclable in your area',
            itemImage: 'milk01',
            price: '£ 2.05',
            bgColor: '#FAF1E1'
        },
    ]
};
export default store;